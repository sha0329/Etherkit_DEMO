/* generated HAL source file - do not edit */
#include "hal_data.h"
#if defined(__GNUC__) || defined(__ICCARM__)
void Default_Error_Handler (uint32_t id)
{
    /* Do nothing. */
    FSP_PARAMETER_NOT_USED(id);
}
#endif

#if defined(__ICCARM__)
 #define WEAK_REF_ATTRIBUTE
#ifndef NULL /* Peripheral error 0 ERREEVENT0 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT1 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT2 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT3 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef bsc_wto_int_isr /* Peripheral error 0 ERREEVENT4 */
 #pragma weak bsc_wto_int_isr = Default_Error_Handler
#endif
#ifndef dmac_err_int_isr /* Peripheral error 0 ERREEVENT5 */
 #pragma weak dmac_err_int_isr = Default_Error_Handler
#endif
#ifndef dmac_err_int_isr /* Peripheral error 0 ERREEVENT6 */
 #pragma weak dmac_err_int_isr = Default_Error_Handler
#endif
#ifndef wdt_underflow_isr /* Peripheral error 0 ERREEVENT7 */
 #pragma weak wdt_underflow_isr = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT8 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT9 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT10 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT11 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT12 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT13 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT14 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT15 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT16 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT17 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT18 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT19 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT20 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT21 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT22 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT23 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT24 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT25 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT26 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT27 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT28 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT29 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT30 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT31 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef doc_int_isr /* Peripheral error 1 ERREEVENT0 */
 #pragma weak doc_int_isr = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 1 ERREEVENT1 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 1 ERREEVENT2 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 1 ERREEVENT3 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 1 ERREEVENT4 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 1 ERREEVENT5 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 1 ERREEVENT6 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 1 ERREEVENT7 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 1 ERREEVENT8 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 1 ERREEVENT9 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 1 ERREEVENT10 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 1 ERREEVENT11 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 1 ERREEVENT12 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 1 ERREEVENT13 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 1 ERREEVENT14 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 1 ERREEVENT15 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 1 ERREEVENT16 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 1 ERREEVENT17 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 1 ERREEVENT18 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 1 ERREEVENT19 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 1 ERREEVENT20 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 1 ERREEVENT21 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 1 ERREEVENT22 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 1 ERREEVENT23 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 1 ERREEVENT24 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 1 ERREEVENT27 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 1 ERREEVENT28 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 1 ERREEVENT29 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 1 ERREEVENT30 */
 #pragma weak NULL = Default_Error_Handler
#endif
#ifndef NULL /* Peripheral error 1 ERREEVENT31 */
 #pragma weak NULL = Default_Error_Handler
#endif

#elif defined(__GNUC__)
 #define WEAK_REF_ATTRIBUTE    __attribute__((weak, alias("Default_Error_Handler")))
#endif

#ifndef NULL /* Peripheral error 0 ERREEVENT0 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id)
WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT1 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT2 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT3 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef bsc_wto_int_isr /* Peripheral error 0 ERREEVENT4 */
#ifndef bsc_wto_int_isr_function
#define bsc_wto_int_isr_function
void bsc_wto_int_isr(uint32_t id)
WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef dmac_err_int_isr /* Peripheral error 0 ERREEVENT5 */
#ifndef dmac_err_int_isr_function
#define dmac_err_int_isr_function
void dmac_err_int_isr(uint32_t id)
WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef dmac_err_int_isr /* Peripheral error 0 ERREEVENT6 */
#ifndef dmac_err_int_isr_function
#define dmac_err_int_isr_function
void dmac_err_int_isr(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef wdt_underflow_isr /* Peripheral error 0 ERREEVENT7 */
#ifndef wdt_underflow_isr_function
#define wdt_underflow_isr_function
void wdt_underflow_isr(uint32_t id)
WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT8 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT9 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT10 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT11 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT12 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT13 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT14 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT15 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT16 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT17 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT18 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT19 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT20 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT21 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT22 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT23 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT24 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT25 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT26 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT27 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT28 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT29 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT30 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 0 ERREEVENT31 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef doc_int_isr /* Peripheral error 1 ERREVENT0 */
#ifndef doc_int_isr_function
#define doc_int_isr_function
void doc_int_isr(uint32_t id)
WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 1 ERREVENT1 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 1 ERREVENT2 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 1 ERREVENT3 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 1 ERREVENT4 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 1 ERREVENT5 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 1 ERREVENT6 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 1 ERREVENT7 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 1 ERREVENT8 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 1 ERREVENT9 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 1 ERREVENT10 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 1 ERREVENT11 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 1 ERREVENT12 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 1 ERREVENT13 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 1 ERREVENT14 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 1 ERREVENT15 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 1 ERREVENT16 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 1 ERREVENT17 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 1 ERREVENT18 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 1 ERREVENT19 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 1 ERREVENT20 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 1 ERREVENT21 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 1 ERREVENT22 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 1 ERREVENT23 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 1 ERREVENT24 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 1 ERREVENT27 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 1 ERREVENT28 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 1 ERREVENT29 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 1 ERREVENT30 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif
#ifndef NULL /* Peripheral error 1 ERREVENT31 */
#ifndef NULL_function
#define NULL_function
void NULL(uint32_t id) WEAK_REF_ATTRIBUTE;
#endif
#endif

static const error_table_t g_error0_handler_table[ERROR_TABLE_MAX_ENTRIES] =
{ [0] = NULL, /* Peripheral error 0 ERREVENT0 */
  [1] = NULL, /* Peripheral error 0 ERREVENT1 */
  [2] = NULL, /* Peripheral error 0 ERREVENT2 */
  [3] = NULL, /* Peripheral error 0 ERREVENT3 */
  [4] = bsc_wto_int_isr, /* Peripheral error 0 ERREVENT4 */
  [5] = dmac_err_int_isr, /* Peripheral error 0 ERREVENT5 */
  [6] = dmac_err_int_isr, /* Peripheral error 0 ERREVENT6 */
  [7] = wdt_underflow_isr, /* Peripheral error 0 ERREVENT7 */
  [8] = NULL, /* Peripheral error 0 ERREVENT8 */
  [9] = NULL, /* Peripheral error 0 ERREVENT9 */
  [10] = NULL, /* Peripheral error 0 ERREVENT10 */
  [11] = NULL, /* Peripheral error 0 ERREVENT11 */
  [12] = NULL, /* Peripheral error 0 ERREVENT12 */
  [13] = NULL, /* Peripheral error 0 ERREVENT13 */
  [14] = NULL, /* Peripheral error 0 ERREVENT14 */
  [15] = NULL, /* Peripheral error 0 ERREVENT15 */
  [16] = NULL, /* Peripheral error 0 ERREVENT16 */
  [17] = NULL, /* Peripheral error 0 ERREVENT17 */
  [18] = NULL, /* Peripheral error 0 ERREVENT18 */
  [19] = NULL, /* Peripheral error 0 ERREVENT19 */
  [20] = NULL, /* Peripheral error 0 ERREVENT20 */
  [21] = NULL, /* Peripheral error 0 ERREVENT21 */
  [22] = NULL, /* Peripheral error 0 ERREVENT22 */
  [23] = NULL, /* Peripheral error 0 ERREVENT23 */
  [24] = NULL, /* Peripheral error 0 ERREVENT24 */
  [25] = NULL, /* Peripheral error 0 ERREVENT25 */
  [26] = NULL, /* Peripheral error 0 ERREVENT26 */
  [27] = NULL, /* Peripheral error 0 ERREVENT27 */
  [28] = NULL, /* Peripheral error 0 ERREVENT28 */
  [29] = NULL, /* Peripheral error 0 ERREVENT29 */
  [30] = NULL, /* Peripheral error 0 ERREVENT30 */
  [31] = NULL, /* Peripheral error 0 ERREVENT31 */
  [32] = doc_int_isr, /* Peripheral error 1 ERREVENT0 */
  [33] = NULL, /* Peripheral error 1 ERREVENT1 */
  [34] = NULL, /* Peripheral error 1 ERREVENT2 */
  [35] = NULL, /* Peripheral error 1 ERREVENT3 */
  [36] = NULL, /* Peripheral error 1 ERREVENT4 */
  [37] = NULL, /* Peripheral error 1 ERREVENT5 */
  [38] = NULL, /* Peripheral error 1 ERREVENT6 */
  [39] = NULL, /* Peripheral error 1 ERREVENT7 */
  [40] = NULL, /* Peripheral error 1 ERREVENT8 */
  [41] = NULL, /* Peripheral error 1 ERREVENT9 */
  [42] = NULL, /* Peripheral error 1 ERREVENT10 */
  [43] = NULL, /* Peripheral error 1 ERREVENT11 */
  [44] = NULL, /* Peripheral error 1 ERREVENT12 */
  [45] = NULL, /* Peripheral error 1 ERREVENT13 */
  [46] = NULL, /* Peripheral error 1 ERREVENT14 */
  [47] = NULL, /* Peripheral error 1 ERREVENT15 */
  [48] = NULL, /* Peripheral error 1 ERREVENT16 */
  [49] = NULL, /* Peripheral error 1 ERREVENT17 */
  [50] = NULL, /* Peripheral error 1 ERREVENT18 */
  [51] = NULL, /* Peripheral error 1 ERREVENT19 */
  [52] = NULL, /* Peripheral error 1 ERREVENT20 */
  [53] = NULL, /* Peripheral error 1 ERREVENT21 */
  [54] = NULL, /* Peripheral error 1 ERREVENT22 */
  [55] = NULL, /* Peripheral error 1 ERREVENT23 */
  [56] = NULL, /* Peripheral error 1 ERREVENT24 */
  [59] = NULL, /* Peripheral error 1 ERREVENT27 */
  [60] = NULL, /* Peripheral error 1 ERREVENT28 */
  [61] = NULL, /* Peripheral error 1 ERREVENT29 */
  [62] = NULL, /* Peripheral error 1 ERREVENT30 */
  [63] = NULL, /* Peripheral error 1 ERREVENT31 */
};

icu_error_instance_ctrl_t g_error0_ctrl;
const icu_error_extended_cfg_t g_error0_extend =
{ .cpu0_err0_ipl = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_CPU0_ERR0)
    .cpu0_err0_irq    = VECTOR_NUMBER_CPU0_ERR0,
#else
  .cpu0_err0_irq = FSP_INVALID_VECTOR,
#endif
  .cpu0_err1_ipl = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_CPU0_ERR1)
    .cpu0_err1_irq    = VECTOR_NUMBER_CPU0_ERR1,
#else
  .cpu0_err1_irq = FSP_INVALID_VECTOR,
#endif
  .peri_err0_ipl = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_PERI_ERR0)
    .peri_err0_irq    = VECTOR_NUMBER_PERI_ERR0,
#else
  .peri_err0_irq = FSP_INVALID_VECTOR,
#endif
  .peri_err1_ipl = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_PERI_ERR1)
    .peri_err1_irq    = VECTOR_NUMBER_PERI_ERR1,
#else
  .peri_err1_irq = FSP_INVALID_VECTOR,
#endif

  .cpu0_err_reset_mask = ~(0UL),
  .cpu0_err0_event_mask = ~(0UL),
  .cpu0_err1_event_mask = ~(0UL),
  .peri_err_event_0_reset_mask = ~((1UL << 7) | 0UL),
  .peri_err0_event_0_mask = ~(0UL),
  .peri_err1_event_0_mask = ~(0UL),
  .peri_err_event_1_reset_mask = ~(0UL),
  .peri_err0_event_1_mask = ~(0UL),
  .peri_err1_event_1_mask = ~(0UL),

  .p_error_handler_table = &g_error0_handler_table[0], };
const error_cfg_t g_error0_cfg =
{ .p_extend = &g_error0_extend, .p_callback = NULL, .p_context = NULL, };
/* Instance structure to use this module. */
const error_instance_t g_error0 =
{ .p_ctrl = &g_error0_ctrl, .p_cfg = &g_error0_cfg, .p_api = &g_error_on_icu_error };
wdt_instance_ctrl_t g_wdt0_ctrl;

const wdt_cfg_t g_wdt0_cfg =
{ .timeout = WDT_TIMEOUT_16384,
  .clock_division = WDT_CLOCK_DIVISION_8192,
  .window_start = WDT_WINDOW_START_100,
  .window_end = WDT_WINDOW_END_0,
  .reset_control = WDT_RESET_CONTROL_NMI,
  .stop_control = WDT_STOP_CONTROL_DISABLE,
  .p_callback = NULL, };

/* Instance structure to use this module. */
const wdt_instance_t g_wdt0 =
{ .p_ctrl = &g_wdt0_ctrl, .p_cfg = &g_wdt0_cfg, .p_api = &g_wdt_on_wdt };
void g_hal_init(void)
{
    g_common_init ();
}
