/* generated HAL source file - do not edit */
#include "hal_data.h"
sci_spi_instance_ctrl_t g_spi3_ctrl;

#define FSP_NOT_DEFINED (1)
#if (FSP_NOT_DEFINED) != (FSP_NOT_DEFINED)

/* If the transfer module is DMAC, define a DMAC transfer callback. */
extern void sci_spi_tx_dmac_callback(sci_spi_instance_ctrl_t * p_instance_ctrl);

void g_spi3_tx_transfer_callback (transfer_callback_args_t * p_args)
{
    FSP_PARAMETER_NOT_USED(p_args);
    sci_spi_tx_dmac_callback(&g_spi3_ctrl);
}
#endif

#if (FSP_NOT_DEFINED) != (FSP_NOT_DEFINED)

/* If the transfer module is DMAC, define a DMAC transfer callback. */
extern void sci_spi_rx_dmac_callback(sci_spi_instance_ctrl_t * p_instance_ctrl);

void g_spi3_rx_transfer_callback (transfer_callback_args_t * p_args)
{
    FSP_PARAMETER_NOT_USED(p_args);
    sci_spi_rx_dmac_callback(&g_spi3_ctrl);
}
#endif
#undef FSP_NOT_DEFINED

/** SPI extended configuration */
const sci_spi_extended_cfg_t g_spi3_cfg_extend =
{
    .clk_div = {
        /* Actual calculated bitrate: 2000000. */ .cks = 0, .brr = 11,
    },
#if 1
    .clock_source = SCI_SPI_CLOCK_SOURCE_SCI3ASYNCCLK,
#else
    .clock_source = SCI_SPI_CLOCK_SOURCE_PCLKM,
#endif
};

const spi_cfg_t g_spi3_cfg =
{
    .channel         = 3,
    .operating_mode  = SPI_MODE_MASTER,
    .clk_phase       = SPI_CLK_PHASE_EDGE_ODD,
    .clk_polarity    = SPI_CLK_POLARITY_LOW,
    .mode_fault      = SPI_MODE_FAULT_ERROR_DISABLE,
    .bit_order       = SPI_BIT_ORDER_MSB_FIRST,
    .p_transfer_tx   = g_spi3_P_TRANSFER_TX,
    .p_transfer_rx   = g_spi3_P_TRANSFER_RX,
    .p_callback      = sci_spi_callback,
    .p_context       = NULL,
    .rxi_irq         = VECTOR_NUMBER_SCI3_RXI,
    .txi_irq         = VECTOR_NUMBER_SCI3_TXI,
    .tei_irq         = VECTOR_NUMBER_SCI3_TEI,
    .eri_irq         = VECTOR_NUMBER_SCI3_ERI,
    .rxi_ipl         = (12),
    .txi_ipl         = (12),
    .tei_ipl         = (12),
    .eri_ipl         = (12),
    .p_extend        = &g_spi3_cfg_extend,
};
/* Instance structure to use this module. */
const spi_instance_t g_spi3 =
{
    .p_ctrl          = &g_spi3_ctrl,
    .p_cfg           = &g_spi3_cfg,
    .p_api           = &g_spi_on_sci
};
void g_hal_init(void) {
g_common_init();
}
