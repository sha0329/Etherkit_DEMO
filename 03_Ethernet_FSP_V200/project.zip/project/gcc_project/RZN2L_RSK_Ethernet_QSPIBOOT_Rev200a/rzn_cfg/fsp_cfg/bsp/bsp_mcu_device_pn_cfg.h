/* generated configuration header file - do not edit */
#ifndef BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_R9A07G084M04GBG
#define BSP_ATCM_SIZE_BYTES (131072)
#define BSP_BTCM_SIZE_BYTES (131072)
#define BSP_SYSTEM_RAM_SIZE_BYTES (1572864)
#define BSP_PACKAGE_FBGA
#define BSP_PACKAGE_PINS (225)

#define BSP_CFG_CORE_CR52 (0)
#endif /* BSP_MCU_DEVICE_PN_CFG_H_ */
