/* generated configuration header file - do not edit */
#ifndef R_ETHER_SELECTOR_CFG_H_
#define R_ETHER_SELECTOR_CFG_H_
#define ETHER_SELECTOR_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
            #define ETHER_SELECTOR_CFG_MODE       (0)
#endif /* R_ETHER_SELECTOR_CFG_H_ */
