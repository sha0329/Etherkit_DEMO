/* generated configuration header file - do not edit */
#ifndef R_ETHER_CFG_H_
#define R_ETHER_CFG_H_
#define GMAC_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)

            #if (FSP_NOT_DEFINED != 1)
            #define GMAC_IMPLEMENT_ETHSW
            #endif
#endif /* R_ETHER_CFG_H_ */
