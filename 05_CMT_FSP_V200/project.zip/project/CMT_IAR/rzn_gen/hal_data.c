/* generated HAL source file - do not edit */
#include "hal_data.h"

cmt_instance_ctrl_t g_timer0_ctrl;
const timer_cfg_t g_timer0_cfg =
{
    .mode                = TIMER_MODE_PERIODIC,
    /* Actual period: 0.19999795199475712 seconds. */ .period_counts = (uint32_t) 0x4c4b, .source_div = (timer_source_div_t)9,
    .channel             = 0,
    .p_callback          = cmt_callback,
    .p_context           = NULL,
    .p_extend            = NULL,
    .cycle_end_ipl       = (20),
#if defined(VECTOR_NUMBER_CMT0_CMI)
    .cycle_end_irq       = VECTOR_NUMBER_CMT0_CMI,
#else
    .cycle_end_irq = FSP_INVALID_VECTOR,
#endif
};
/* Instance structure to use this module. */
const timer_instance_t g_timer0 =
{
    .p_ctrl        = &g_timer0_ctrl,
    .p_cfg         = &g_timer0_cfg,
    .p_api         = &g_timer_on_cmt
};
void g_hal_init(void) {
g_common_init();
}
