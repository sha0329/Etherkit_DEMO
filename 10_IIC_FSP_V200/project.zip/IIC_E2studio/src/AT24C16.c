#include "hal_data.h"

#include "AT24C16.h"
unsigned int timeout_ms = 100;
extern uint8_t g_i2c_callback_event;
extern uint8_t tx_buffer[20];
void AT24C16_ByteRead(unsigned char* ptr_read,unsigned int address,unsigned char byte)
{
    uint8_t addr_high1 = (address >> 8) & 0xFF;
    uint8_t addr_low1 = address & 0xFF;
    uint8_t addr_buffer[2] = {addr_high1, addr_low1};
    g_i2c_callback_event =0;
    R_IIC_MASTER_Write(&g_i2c_master0_ctrl, &addr_buffer[0], 2, true);//false
    while ((I2C_MASTER_EVENT_TX_COMPLETE != g_i2c_callback_event))  
    {
        R_BSP_SoftwareDelay(100U, BSP_DELAY_UNITS_MICROSECONDS);
        
    }
    g_i2c_callback_event =0;
    R_IIC_MASTER_Read(&g_i2c_master0_ctrl, ptr_read, byte, false);
    while ((I2C_MASTER_EVENT_RX_COMPLETE != g_i2c_callback_event))  
    {
        R_BSP_SoftwareDelay(100U, BSP_DELAY_UNITS_MICROSECONDS);
        
    }
    g_i2c_callback_event =0;
}
void AT24C16_ByteWrite(uint8_t* ptr_read,unsigned int address,uint8_t byte)
{
    uint8_t addr_high2 = (address >> 8) & 0xFF;
    uint8_t addr_low2 = address & 0xFF;
    tx_buffer[0] = addr_high2;
    tx_buffer[1] = addr_low2;
    g_i2c_callback_event =0;
    R_IIC_MASTER_Write(&g_i2c_master0_ctrl, ptr_read, byte, false); 

    while ((I2C_MASTER_EVENT_TX_COMPLETE != g_i2c_callback_event))
    {
      R_BSP_SoftwareDelay(100U, BSP_DELAY_UNITS_MICROSECONDS);

   }
    g_i2c_callback_event =0;
    timeout_ms = 500;
}

