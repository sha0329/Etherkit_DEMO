//void M24C02_Write(uint8_t Deviceadr,uint8_t Byteadr,uint8_t *  Tx_buf,uint16_t Tx_num);
//void M24C02_Read(uint8_t Deviceadr,uint8_t Byteadr,uint8_t *  Rx_buf,uint16_t Rx_num);
void AT24C16_ByteRead(unsigned char* ptr_read,unsigned int address,unsigned char byte);
void AT24C16_ByteWrite(unsigned char* ptr_read,unsigned int address,unsigned char byte);