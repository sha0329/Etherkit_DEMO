/* generated HAL source file - do not edit */
#include "hal_data.h"
iic_master_instance_ctrl_t g_i2c_master0_ctrl;

#define FSP_NOT_DEFINED (1)
#if (FSP_NOT_DEFINED) != (FSP_NOT_DEFINED)

/* If the transfer module is DMAC, define a DMAC transfer callback. */
extern void iic_master_tx_dmac_callback(iic_master_instance_ctrl_t * p_instance_ctrl);

void g_i2c_master0_tx_transfer_callback (transfer_callback_args_t * p_args)
{
    FSP_PARAMETER_NOT_USED(p_args);
    iic_master_tx_dmac_callback(&g_i2c_master0_ctrl);
}
#endif

#if (FSP_NOT_DEFINED) != (FSP_NOT_DEFINED)

/* If the transfer module is DMAC, define a DMAC transfer callback. */
extern void iic_master_rx_dmac_callback(iic_master_instance_ctrl_t * p_instance_ctrl);

void g_i2c_master0_rx_transfer_callback (transfer_callback_args_t * p_args)
{
    FSP_PARAMETER_NOT_USED(p_args);
    iic_master_rx_dmac_callback(&g_i2c_master0_ctrl);
}
#endif
#undef FSP_NOT_DEFINED

const iic_master_extended_cfg_t g_i2c_master0_extend =
{ .timeout_mode = IIC_MASTER_TIMEOUT_MODE_SHORT, .timeout_scl_low = IIC_MASTER_TIMEOUT_SCL_LOW_ENABLED,
/* Actual calculated bitrate: 98425. Actual calculated duty cycle: 50%. */.clock_settings.brl_value = 28,
  .clock_settings.brh_value = 28, .clock_settings.cks_value = 3 };
const i2c_master_cfg_t g_i2c_master0_cfg =
{ .channel = 0,
  .rate = I2C_MASTER_RATE_STANDARD,
  .slave = 0x50,
  .addr_mode = I2C_MASTER_ADDR_MODE_7BIT,
  .p_transfer_tx = g_i2c_master0_P_TRANSFER_TX,
  .p_transfer_rx = g_i2c_master0_P_TRANSFER_RX,
  .p_callback = iic_callback,
  .p_context = NULL,
#if defined(VECTOR_NUMBER_IIC0_RXI)
    .rxi_irq             = VECTOR_NUMBER_IIC0_RXI,
#else
  .rxi_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_IIC0_TXI)
    .txi_irq             = VECTOR_NUMBER_IIC0_TXI,
#else
  .txi_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_IIC0_TEI)
    .tei_irq             = VECTOR_NUMBER_IIC0_TEI,
#else
  .tei_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_IIC0_EEI)
    .eri_irq             = VECTOR_NUMBER_IIC0_EEI,
#else
  .eri_irq = FSP_INVALID_VECTOR,
#endif
  .ipl = (12),
  .p_extend = &g_i2c_master0_extend, };
/* Instance structure to use this module. */
const i2c_master_instance_t g_i2c_master0 =
{ .p_ctrl = &g_i2c_master0_ctrl, .p_cfg = &g_i2c_master0_cfg, .p_api = &g_i2c_master_on_iic };
void g_hal_init(void)
{
    g_common_init ();
}
