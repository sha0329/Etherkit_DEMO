/* generated vector source file - do not edit */
        #include "bsp_api.h"
        /* Do not build these data structures if no interrupts are currently allocated because IAR will have build errors. */
        #if VECTOR_DATA_IRQ_COUNT > 0
        BSP_DONT_REMOVE const fsp_vector_t g_vector_table[BSP_ICU_VECTOR_MAX_ENTRIES] =
        {
                        [308] = iic_master_eri_isr, /* IIC0_EEI (IIC0 Transfer error or event generation) */
            [309] = iic_master_rxi_isr, /* IIC0_RXI (IIC0 Receive data full) */
            [310] = iic_master_txi_isr, /* IIC0_TXI (IIC0 Transmit data empty) */
            [311] = iic_master_tei_isr, /* IIC0_TEI (IIC0 Transmit end) */
        };
        #endif