/* generated configuration header file - do not edit */
#ifndef R_ETHER_SWITCH_CFG_H_
#define R_ETHER_SWITCH_CFG_H_
#define ETHER_SWITCH_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)

#define BSP_FEATURE_ETHER_SWITCH_MAX_CHANNELS   (1U)
#endif /* R_ETHER_SWITCH_CFG_H_ */
