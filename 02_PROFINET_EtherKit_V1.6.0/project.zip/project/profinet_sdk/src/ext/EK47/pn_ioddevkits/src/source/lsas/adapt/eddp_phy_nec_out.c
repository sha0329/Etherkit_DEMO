/*****************************************************************************/
/*  Copyright (C) 2020 Siemens Aktiengesellschaft. All rights reserved.      */
/*****************************************************************************/
/*  This program is protected by German copyright law and international      */
/*  treaties. The use of this software including but not limited to its      */
/*  Source Code is subject to restrictions as agreed in the license          */
/*  agreement between you and Siemens.                                       */
/*  Copying or distribution is not allowed unless expressly permitted        */
/*  according to your license agreement with Siemens.                        */
/*****************************************************************************/
/*                                                                           */
/*  P r o j e c t         &P: PROFINET IO Runtime Software              :P&  */
/*                                                                           */
/*  P a c k a g e         &W: PROFINET IO Runtime Software              :W&  */
/*                                                                           */
/*  C o m p o n e n t     &C: PnIODDevkits                              :C&  */
/*                                                                           */
/*  F i l e               &F: eddp_phy_nec_out.c                        :F&  */
/*                                                                           */
/*  V e r s i o n         &V: PnIODDevkits_P04.07.01.01_00.01.00.18     :V&  */
/*                                                                           */
/*  D a t e  (YYYY-MM-DD) &D: 2020-11-09                                :D&  */
/*                                                                           */
/*****************************************************************************/
/*                                                                           */
/*  D e s c r i p t i o n :                                                  */
/*                                                                           */
/*  This file contains sample implementations for PHY-specific functions	 */
/*  that have to be provided by system adaption.							 */
/*                                                                           */
/*****************************************************************************/

/*****************************************************************************/
/*                                                                           */
/*  H i s t o r y :                                                          */
/*  ________________________________________________________________________ */
/*                                                                           */
/*  Date        Who   What                                                   */
#ifdef EDDP_MESSAGE
/*  28.04.11    SF    initial version                                        */
#endif
/*****************************************************************************/
#include "lsas_inc.h"

#if defined LSAS_CFG_USE_EDDP

#include "eddp_inc.h"
#include "eddp_int.h"
#include "eddp_phy.h"
#include "eddp_phy_nec.h"

#ifdef EDDP_CFG_PHY_NEC_SUPPORT

#define LSAS_MODULE_ID      114
#define EDDP_MODULE_ID      EDDP_MODULE_ID_EDDP_PHY_NEC /* EDDP_MODULE_ID_EDDP_PHY_NEC */


#ifndef EDDP_CFG_PHY_NEC_MEDIA_TYPE_INTERNAL
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+  Functionname          :    EDDP_PHY_NEC_GET_MEDIA_TYPE                 +*/
/*+  Input/Output          :    EDDP_HANDLE             hDDB                +*/
/*+                        :    EDDP_SYS_HANDLE         hSysDev             +*/
/*+                        :    LSA_UINT32              HwPortID            +*/
/*+                        :    LSA_UINT8               *pMediaType         +*/
/*+                                                                         +*/
/*+  Result                :    LSA_VOID                                    +*/
/*+-------------------------------------------------------------------------+*/
/*+  Input/Output:                                                          +*/
/*+                                                                         +*/
/*+   hDDB       : EDDP Handle                                         (in) +*/
/*+   hSysDev    : Handle of system adaption                           (in) +*/
/*+   HwPortID   : Hardware port ID of the related PHY (1..x)          (in) +*/
/*+   pMediaType : Pointer to address for returned MediaType of port.  (out)+*/
/*+                EDD_MEDIATYPE_COPPER_CABLE                               +*/
/*+                EDD_MEDIATYPE_RADIO_COMMUNICATION                        +*/
/*+                EDD_MEDIATYPE_FIBER_OPTIC_CABLE                          +*/
/*+                                                                         +*/
/*+  Results     : LSA_VOID or EDDP_FATAL()                                 +*/
/*+-------------------------------------------------------------------------+*/
/*+  Description: Get MediaType of a port for internal NEC PHY.             +*/
/*+                                                                         +*/
/*+       Note:   EDDP expects this function to execute with success.       +*/
/*+               Otherwise a fatal error must be generated.                +*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
#ifndef EDDP_PHY_NEC_GET_MEDIA_TYPE
LSA_VOID EDDP_SYSTEM_OUT_FCT_ATTR EDDP_PHY_NEC_GET_MEDIA_TYPE(
    EDDP_HANDLE             hDDB,
    EDDP_SYS_HANDLE         hSysDev,
    LSA_UINT32              HwPortID,
    LSA_UINT8               *pMediaType,
    LSA_UINT8               *pOpticalTransType,
    LSA_UINT8               *pFxTransceiverType)
{
    LSA_UNUSED_ARG(hDDB);
    LSA_UNUSED_ARG(hSysDev);

    if(LSAS_PORT_IS_FO(HwPortID))
    {
        *pMediaType         = EDD_MEDIATYPE_FIBER_OPTIC_CABLE;
        *pFxTransceiverType = LSAS_PORT_GET_FO_TRANSCEIVER_TYPE(HwPortID);  // for example EDD_FX_TRANSCEIVER_QFBR5978 (POF) or EDD_FX_TRANSCEIVER_AFBR59E4APZ (LC)
        if(LSAS_PORT_IS_POF(HwPortID))
        {
            *pOpticalTransType  = LSA_TRUE;
        }
        else
        {
            *pOpticalTransType  = LSA_FALSE;
        }
    }
    else
    {
        *pMediaType         = EDD_MEDIATYPE_COPPER_CABLE;
        *pOpticalTransType  = LSA_FALSE;
        *pFxTransceiverType = EDD_FX_TRANSCEIVER_UNKNOWN;

    }

    return;
}
#endif  // EDDP_PHY_NEC_GET_MEDIA_TYPE
#endif  // EDDP_CFG_PHY_NEC_MEDIA_TYPE_INTERNAL


#ifndef EDDP_CFG_PHY_NEC_MAU_TYPE_INTERNAL
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+  Functionname          :    EDDP_PHY_NEC_GET_MAU_TYPE                   +*/
/*+  Input/Output          :    EDDP_HANDLE             hDDB                +*/
/*+                        :    EDDP_SYS_HANDLE         hSysDev             +*/
/*+                        :    LSA_UINT32              HwPortID            +*/
/*+                        :    LSA_UINT32              Speed               +*/
/*+                        :    LSA_UINT23              Duplexity           +*/
/*+                        :    LSA_UINT16              *pMauType           +*/
/*+                                                                         +*/
/*+  Result                :    LSA_VOID                                    +*/
/*+-------------------------------------------------------------------------+*/
/*+  Input/Output:                                                          +*/
/*+                                                                         +*/
/*+   hDDB       : EDDP Handle                                         (in) +*/
/*+   hSysDev    : Handle of system adaption                           (in) +*/
/*+   HwPortID   : Hardware port ID of the related PHY (1..x)          (in) +*/
/*+   Speed      : Actual Speed of the Link                            (in) +*/
/*+                EDD_LINK_SPEED_10                                        +*/
/*+                EDD_LINK_SPEED_100                                       +*/
/*+   Duplexity  : Actual duplexity of link                            (in) +*/
/*+                EDD_LINK_MODE_HALF                                       +*/
/*+                EDD_LINK_MODE_FULL                                       +*/
/*+   pMauType   : Pointer to address for returned MAUType of port.    (out)+*/
/*+                for COPPER_CABLE & RADIO_COMMUNICATION:                  +*/
/*+                10BASETXHD                                               +*/
/*+                10BASETXFD                                               +*/
/*+                100BASETXHD                                              +*/
/*+                100BASETXFD                                              +*/
/*+                for FIBER_OPTIC_CABLE:                                   +*/
/*+                100BASEFXHD                                              +*/
/*+                100BASEFXFD                                              +*/
/*+                                                                         +*/
/*+  Results     : LSA_VOID or EDDP_FATAL()                                 +*/
/*+-------------------------------------------------------------------------+*/
/*+  Description: Get MAUType of a port for internal NEC PHY                +*/
/*+                                                                         +*/
/*+       Note:   EDDP expects this function to execute with success.       +*/
/*+               Otherwise a fatal error must be generated.                +*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
#ifndef EDDP_PHY_NEC_GET_MAU_TYPE
LSA_VOID EDDP_SYSTEM_OUT_FCT_ATTR EDDP_PHY_NEC_GET_MAU_TYPE(
    EDDP_HANDLE             hDDB,
    EDDP_SYS_HANDLE         hSysDev,
    LSA_UINT32              HwPortID,
    LSA_UINT32              Speed,
    LSA_UINT32              Duplexity,
    LSA_UINT16             *pMauType)
{
	LSA_UINT32      DevId;

    *pMauType = EDD_MAUTYPE_UNKNOWN;

	/* because we cant use hSysDev we use EDDP internal variables */
	DevId = ((EDDP_LOCAL_DDB_PTR_TYPE)hDDB)->DevId;
	EDDP_ASSERT_FALSE(DevId >= EDDP_CFG_MAX_DEVICES);

    LSA_UNUSED_ARG(hSysDev);
	
    if (g_EDDP_PHY_MEDIATYPE[DevId][HwPortID-1] == EDD_MEDIATYPE_FIBER_OPTIC_CABLE)
    {
        /* ---------------------------------------- */
        /* FIBER_OPTIC_CABLE                        */
        /* ---------------------------------------- */
        if (Speed == EDD_LINK_SPEED_100)
        {
            if (Duplexity == EDD_LINK_MODE_HALF)
            {
                *pMauType = EDDP_PHY_MAUTYPE_100BASEFXHD;
            }
            else if (LSAS_PORT_IS_POF(HwPortID))
            {
                /* according to RQ 215001, we have to set 0x36 as POF-MAU type */
                *pMauType = EDDP_PHY_MAUTYPE_100BASEPXFD;
            }
            else
            {
                *pMauType = EDDP_PHY_MAUTYPE_100BASEFXFD;
            }
            return;
        }
    }
    else
    {
        /* ---------------------------------------- */
        /* COPPER_CABLE & RADIO_COMMUNICATION       */
        /* ---------------------------------------- */
        if (Speed == EDD_LINK_SPEED_10)
        {
            if (Duplexity == EDD_LINK_MODE_HALF)
            {
                *pMauType = EDDP_PHY_MAUTYPE_10BASETXHD;
            }
            else
            {
                *pMauType = EDDP_PHY_MAUTYPE_10BASETXFD;
            }
            return;
        }

        if (Speed == EDD_LINK_SPEED_100 /*&& ! FIBER_OPTIC_CABLE*/)
        {
            if (Duplexity == EDD_LINK_MODE_HALF)
            {
                *pMauType = EDDP_PHY_MAUTYPE_100BASETXHD;
            }
            else
            {
                *pMauType = EDDP_PHY_MAUTYPE_100BASETXFD;
            }
            return;
        }
    }

    EDDP_FATAL(EDDP_FATAL_ERR_NOT_SUPPORTED);
}
#endif  // EDDP_PHY_NEC_GET_MAU_TYPE
#endif  // EDDP_CFG_PHY_NEC_MAU_TYPE_INTERNAL




#ifndef EDDP_CFG_PHY_NEC_MAU_TYPE_INTERNAL
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+  Functionname          :    EDDP_PHY_NEC_CHECK_MAU_TYPE                 +*/
/*+  Input/Output          :    EDDP_HANDLE             hDDB                +*/
/*+                        :    EDDP_SYS_HANDLE         hSysDev             +*/
/*+                        :    LSA_UINT32              HwPortID            +*/
/*+                        :    LSA_UINT16              MAUType             +*/
/*+                        :    LSA_UINT32              *pSpeed             +*/
/*+                        :    LSA_UINT23              *pDuplexity         +*/
/*+                                                                         +*/
/*+  Result                :    LSA_VOID                                    +*/
/*+-------------------------------------------------------------------------+*/
/*+  Input/Output:                                                          +*/
/*+                                                                         +*/
/*+   hDDB       : EDDP Handle                                         (in) +*/
/*+   hSysDev    : Handle of system adaption                           (in) +*/
/*+   HwPortID   : Hardware port ID of the related PHY (1..x)          (in) +*/
/*+   MAUType    : MAU Type to be checked                              (in) +*/
/*+                for COPPER_CABLE & RADIO_COMMUNICATION:                  +*/
/*+                10BASETXHD                                               +*/
/*+                10BASETXFD                                               +*/
/*+                100BASETXHD                                              +*/
/*+                100BASETXFD                                              +*/
/*+                for FIBER_OPTIC_CABLE:                                   +*/
/*+                100BASEFXHD                                              +*/
/*+                100BASEFXFD                                              +*/
/*+   pSpeed     : Speed for given MAU Type                            (out)+*/
/*+                EDD_LINK_SPEED_10                                        +*/
/*+                EDD_LINK_SPEED_100                                       +*/
/*+   pDuplexity : Mode for given MAU Type                             (out)+*/
/*+                EDD_LINK_MODE_HALF                                       +*/
/*+                EDD_LINK_MODE_FULL                                       +*/
/*+                                                                         +*/
/*+  Results     : EDD_STS_OK        (MAUType is supported by hardware)     +*/
/*+              : EDD_STS_ERR_PARAM (MAUType is NOT supported by hardware) +*/
/*+-------------------------------------------------------------------------+*/
/*+  Description: This function checks if the given MAUType is supported by +*/
/*+               the hardware and returns the related Speed and Duplexity. +*/
/*+                                                                         +*/
/*+       Note:   EDDP expects this function to execute with success.       +*/
/*+               Otherwise a fatal error must be generated.                +*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
EDD_RSP EDDP_SYSTEM_OUT_FCT_ATTR EDDP_PHY_NEC_CHECK_MAU_TYPE(
    EDDP_HANDLE             hDDB,
    EDDP_SYS_HANDLE         hSysDev,
    LSA_UINT32              HwPortID,
    LSA_UINT16              MAUType,
    LSA_UINT32              *pSpeed,
    LSA_UINT32              *pDuplexity)
{
	LSA_UINT32      DevId;

    *pSpeed     = EDD_LINK_UNKNOWN;
    *pDuplexity = EDD_LINK_UNKNOWN;

	/* because we cant use hSysDev we use EDDP internal variables */
	DevId = ((EDDP_LOCAL_DDB_PTR_TYPE)hDDB)->DevId;
	EDDP_ASSERT_FALSE(DevId >= EDDP_CFG_MAX_DEVICES);

    LSA_UNUSED_ARG(hSysDev);

    // ***** FIBER_OPTIC_CABLE
    if ( g_EDDP_PHY_MEDIATYPE[DevId][HwPortID-1] == EDD_MEDIATYPE_FIBER_OPTIC_CABLE )
    {
        if( MAUType == EDDP_PHY_MAUTYPE_100BASEFXHD )         // 17/11h
        {   // ***** FIBER_OPTIC_CABLE
            *pSpeed = EDD_LINK_SPEED_100;
            *pDuplexity  = EDD_LINK_MODE_HALF;
            return EDD_STS_OK;
        }
        else if( MAUType == EDDP_PRM_PDPORT_DATA_MAUTYPE_100BASEPXFD )    // 54/36h
        {   // ***** FIBER_OPTIC_CABLE (POF)
            *pSpeed = EDD_LINK_SPEED_100;
            *pDuplexity  = EDD_LINK_MODE_FULL;
            return EDD_STS_OK;
        }
        else if (MAUType == EDDP_PHY_MAUTYPE_100BASEFXFD)
        {
            // ***** GOF
            *pSpeed     = EDD_LINK_SPEED_100;
            *pDuplexity = EDD_LINK_MODE_FULL;
            return EDD_STS_OK;
        }
    }
    else // ***** COPPER_CABLE & RADIO_COMMUNICATION
    {
        if( MAUType == EDDP_PHY_MAUTYPE_10BASETXHD    )         // 10/0Ah
        {   // ***** COPPER_CABLE & RADIO_COMMUNICATION
            *pSpeed = EDD_LINK_SPEED_10;
            *pDuplexity  = EDD_LINK_MODE_HALF;
            return EDD_STS_OK;
        }
        else if( MAUType == EDDP_PHY_MAUTYPE_10BASETXFD )     // 11/0Bh
        {   // ***** COPPER_CABLE & RADIO_COMMUNICATION
            *pSpeed = EDD_LINK_SPEED_10;
            *pDuplexity  = EDD_LINK_MODE_FULL;
            return EDD_STS_OK;
        }
        else if( MAUType == EDDP_PHY_MAUTYPE_100BASETXHD )    // 15/0Fh
        {   // ***** COPPER_CABLE & RADIO_COMMUNICATION
            *pSpeed = EDD_LINK_SPEED_100;
            *pDuplexity  = EDD_LINK_MODE_HALF;
            return EDD_STS_OK;
        }
        else if( MAUType == EDDP_PHY_MAUTYPE_100BASETXFD )    // 16/10h
        {   // ***** COPPER_CABLE & RADIO_COMMUNICATION
            *pSpeed = EDD_LINK_SPEED_100;
            *pDuplexity  = EDD_LINK_MODE_FULL;
            return EDD_STS_OK;
        }
    }

    return EDD_STS_ERR_PARAM;
}
#endif  // EDDP_CFG_PHY_NEC_MAU_TYPE_INTERNAL


/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+  Functionname          :    EDDP_PHY_NEC_LED_BlinkBegin                 +*/
/*+  Input/Output          :    EDDP_HANDLE         hDDB                    +*/
/*+                        :    EDDP_SYS_HANDLE     hSysDev                 +*/
/*+                        :    LSA_UINT32          HwPortID                +*/
/*+                                                                         +*/
/*+  Result                :    EDD_RSP                                     +*/
/*+-------------------------------------------------------------------------+*/
/*+  Input/Output:                                                          +*/
/*+                                                                         +*/
/*+   hDDB       : EDDP Handle                                         (in) +*/
/*+   hSysDev    : Handle of system adaption                           (in) +*/
/*+   HwPortID   : Hardware port ID of the related PHY                 (in) +*/
/*+                                                                         +*/
/*+  Results     : EDD_STS_OK                                               +*/
/*+-------------------------------------------------------------------------+*/
/*+  Description: EDDP calls this function within the service               +*/
/*+               EDD_SRV_LED_BLINK() before the LED(s) start to blink. Can +*/
/*+               be used e.g. to diable the link/activity LED function of  +*/
/*+               a PHY if necessary.                                       +*/
/*+                                                                         +*/
/*+       Note:   EDDP expects this function to return with success. Any    +*/
/*+               other return value than �EDD_STS_OK� will be interpreted  +*/
/*+               as a fatal error.                                         +*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
EDD_RSP EDDP_SYSTEM_OUT_FCT_ATTR EDDP_PHY_NEC_LED_BlinkBegin(
	EDDP_HANDLE 	    hDDB,
	EDDP_SYS_HANDLE     hSysDev,	
	LSA_UINT32          HwPortID)
{
    //LSA_UINT32        RegVal;

    LSA_UNUSED_ARG(hDDB);
    LSA_UNUSED_ARG(hSysDev);
    LSA_UNUSED_ARG(HwPortID);

    EDDP_SWI_TRACE_00(EDDP_UNDEF_TRACE_IDX, LSA_TRACE_LEVEL_CHAT," +++ EDDP_PHY_LED_BlinkBegin +++ ");

    LSAS_EDD_PHY_LED_BLINK_BEGIN(HwPortID);
    /*
    RegVal = ApbPer.Scrb.PHY_LED_CONTROL
    switch (HwPortID)
    {
        // ***** EN_P1_XLINK_STATUS + EN_P1_XACTIVITY --> controled by SW
        case 1:
            RegVal |= 0x03;
            ApbPer.Scrb.PHY_LED_CONTROL = RegVal;
            break;
        // ***** EN_P2_XLINK_STATUS + EN_P2_XACTIVITY --> controled by SW
        case 2:
            RegVal |= 0x0C;
            ApbPer.Scrb.PHY_LED_CONTROL = RegVal;
            break;
        default:
            break;
    }
    */

    return (EDD_STS_OK);
}

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+  Functionname          :    EDDP_PHY_NEC_LED_BlinkSetMode               +*/
/*+  Input/Output          :    EDDP_HANDLE         hDDB                    +*/
/*+                        :    EDDP_SYS_HANDLE     hSysDev                 +*/
/*+                        :    LSA_UINT32          HwPortID                +*/
/*+                        :    LSA_UINT32		    LEDMode                 +*/
/*+                                                                         +*/
/*+  Result                :    EDD_RSP                                     +*/
/*+-------------------------------------------------------------------------+*/
/*+  Input/Output:                                                          +*/
/*+                                                                         +*/
/*+   hDDB       : EDDP Handle                                         (in) +*/
/*+   hSysDev    : Handle of system adaption                           (in) +*/
/*+   HwPortID   : Hardware port ID of the related PHY                 (in) +*/
/*+   LEDMode    : Turns the LED(s) ON or OFF                          (in) +*/
/*+                                                                         +*/
/*+  Results     : EDD_STS_OK                                               +*/
/*+-------------------------------------------------------------------------+*/
/*+  Description: EDDP calls this function repeatedly within the service    +*/
/*+               EDD_SRV_LED_BLINK() in order to turn on and turn off the  +*/
/*+               LED(s) alternately.                                       +*/
/*+                                                                         +*/
/*+       Note:   EDDP expects this function to return with success. Any    +*/
/*+               other return value than �EDD_STS_OK� will be interpreted  +*/
/*+               as a fatal error.                                         +*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
EDD_RSP EDDP_SYSTEM_OUT_FCT_ATTR EDDP_PHY_NEC_LED_BlinkSetMode(
	EDDP_HANDLE 	    hDDB,
	EDDP_SYS_HANDLE     hSysDev,	
	LSA_UINT32          HwPortID,
	LSA_UINT32		    LEDMode)
{
    LSA_UNUSED_ARG(hDDB);
    LSA_UNUSED_ARG(hSysDev);
    LSA_UNUSED_ARG(HwPortID);

    switch(LEDMode)
    {
        case EDDP_LED_MODE_OFF:
            //LedVal = 0;
            EDDP_SWI_TRACE_00(EDDP_UNDEF_TRACE_IDX, LSA_TRACE_LEVEL_CHAT," +++ EDDP_PHY_LED_BlinkSetMode | LED OFF | +++ ");
        break;

        case EDDP_LED_MODE_ON:
            //LedVal = 1;
            EDDP_SWI_TRACE_00(EDDP_UNDEF_TRACE_IDX, LSA_TRACE_LEVEL_CHAT," +++ EDDP_PHY_LED_BlinkSetMode | LED ON  | +++ ");
        break;

        default:
            EDDP_SWI_TRACE_00(EDDP_UNDEF_TRACE_IDX, LSA_TRACE_LEVEL_ERROR," +++ ERROR -> Wrong LED Mode! +++ ");
        break;
    }

    LSAS_EDD_PHY_LED_SET_MODE(HwPortID, LEDMode);

    /*
    RegVal = ApbPer.Scrb.PHY_LED_CONTROL

    switch (HwPortID)
    {
        // ***** P1_XLINK_STATUS_SW + EN_P1_XACTIVITY_SW 
        case 1:
            RegVal &= 0xFFFFFCFF;
            if (LedVal)
            {
                RegVal |= 0x0300;
            }
            break;
        // ***** EN_P2_XLINK_STATUS_SW + EN_P2_XACTIVITY_SW 
        case 2:
            RegVal &= 0xFFFFF3FF;
            if (LedVal)
            {
                RegVal |= 0x0C00;
            }
            break;
        default:
            LedVal = 2;
            break;
    }
    if (LedVal < 2)
    {
        ApbPer.Scrb.PHY_LED_CONTROL = RegVal;
    }
    */

	return (EDD_STS_OK);
}

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+  Functionname          :    EDDP_PHY_NEC_LED_BlinkEnd                   +*/
/*+  Input/Output          :    EDDP_HANDLE         hDDB                    +*/
/*+                        :    EDDP_SYS_HANDLE     hSysDev                 +*/
/*+                        :    LSA_UINT32          HwPortID                +*/
/*+                                                                         +*/
/*+  Result                :    EDD_RSP                                     +*/
/*+-------------------------------------------------------------------------+*/
/*+  Input/Output:                                                          +*/
/*+                                                                         +*/
/*+   hDDB       : EDDP Handle                                         (in) +*/
/*+   hSysDev    : Handle of system adaption                           (in) +*/
/*+   HwPortID   : Hardware port ID of the related PHY                 (in) +*/
/*+                                                                         +*/
/*+  Results     : EDD_STS_OK                                               +*/
/*+-------------------------------------------------------------------------+*/
/*+  Description: EDDP calls this function within the service               +*/
/*+               EDD_SRV_LED_BLINK() after blinking of LED(s) has finished.+*/
/*+               Can be used e.g. to re-enable the link/activity LED       +*/
/*+               function of a PHY if necessary.                           +*/
/*+                                                                         +*/
/*+       Note:   EDDP expects this function to return with success. Any    +*/
/*+               other return value than �EDD_STS_OK� will be interpreted  +*/
/*+               as a fatal error.                                         +*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
EDD_RSP EDDP_SYSTEM_OUT_FCT_ATTR EDDP_PHY_NEC_LED_BlinkEnd(
	EDDP_HANDLE 	    hDDB,
	EDDP_SYS_HANDLE     hSysDev,	
	LSA_UINT32          HwPortID)
{
    //LSA_UINT32     RegVal;
    LSA_UNUSED_ARG(hDDB);
    LSA_UNUSED_ARG(hSysDev);
    LSA_UNUSED_ARG(HwPortID);

    EDDP_SWI_TRACE_00(EDDP_UNDEF_TRACE_IDX, LSA_TRACE_LEVEL_CHAT," +++ EDDP_PHY_LED_BlinkEnd +++ ");

    LSAS_EDD_PHY_LED_BLINK_END(HwPortID);

    /* 
    RegVal = ApbPer.Scrb.PHY_LED_CONTROL
    switch (HwPortID)
    {
        // ***** EN_P1_XLINK_STATUS + EN_P1_XACTIVITY --> controled by PHY
        case 1:
            RegVal &= 0xFFFFFFFC;
            ApbPer.Scrb.PHY_LED_CONTROL = RegVal;
            break;
        // ***** EN_P2_XLINK_STATUS + EN_P2_XACTIVITY --> controled by PHY 
        case 2:
            RegVal &= 0xFFFFFFF3;
            ApbPer.Scrb.PHY_LED_CONTROL = RegVal;
            break;
        default:
            break;
    }
    */

	return (EDD_STS_OK);
}
#endif  // EDDP_CFG_PHY_NEC_SUPPORT

#endif

/*****************************************************************************/
/*  end of file eddp_phy_nec_out.c                                           */
/*****************************************************************************/

/*****************************************************************************/
/*  Copyright (C) 2020 Siemens Aktiengesellschaft. All rights reserved.      */
/*****************************************************************************/
