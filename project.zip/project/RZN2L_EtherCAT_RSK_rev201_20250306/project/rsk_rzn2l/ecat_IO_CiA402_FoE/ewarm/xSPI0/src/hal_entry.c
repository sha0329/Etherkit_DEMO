/***********************************************************************************************************************
 * Copyright [2020-2023] Renesas Electronics Corporation and/or its affiliates.  All Rights Reserved.
 *
 * This software and documentation are supplied by Renesas Electronics Corporation and/or its affiliates and may only
 * be used with products of Renesas Electronics Corp. and its affiliates ("Renesas").  No other uses are authorized.
 * Renesas products are sold pursuant to Renesas terms and conditions of sale.  Purchasers are solely responsible for
 * the selection and use of Renesas products and Renesas assumes no liability.  No license, express or implied, to any
 * intellectual property right is granted by Renesas.  This software is protected under all applicable laws, including
 * copyright laws. Renesas reserves the right to change or discontinue this software and/or this documentation.
 * THE SOFTWARE AND DOCUMENTATION IS DELIVERED TO YOU "AS IS," AND RENESAS MAKES NO REPRESENTATIONS OR WARRANTIES, AND
 * TO THE FULLEST EXTENT PERMISSIBLE UNDER APPLICABLE LAW, DISCLAIMS ALL WARRANTIES, WHETHER EXPLICITLY OR IMPLICITLY,
 * INCLUDING WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NONINFRINGEMENT, WITH RESPECT TO THE
 * SOFTWARE OR DOCUMENTATION.  RENESAS SHALL HAVE NO LIABILITY ARISING OUT OF ANY SECURITY VULNERABILITY OR BREACH.
 * TO THE MAXIMUM EXTENT PERMITTED BY LAW, IN NO EVENT WILL RENESAS BE LIABLE TO YOU IN CONNECTION WITH THE SOFTWARE OR
 * DOCUMENTATION (OR ANY PERSON OR ENTITY CLAIMING RIGHTS DERIVED FROM YOU) FOR ANY LOSS, DAMAGES, OR CLAIMS WHATSOEVER,
 * INCLUDING, WITHOUT LIMITATION, ANY DIRECT, CONSEQUENTIAL, SPECIAL, INDIRECT, PUNITIVE, OR INCIDENTAL DAMAGES; ANY
 * LOST PROFITS, OTHER ECONOMIC DAMAGE, PROPERTY DAMAGE, OR PERSONAL INJURY; AND EVEN IF RENESAS HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH LOSS, DAMAGES, CLAIMS OR COSTS.
 **********************************************************************************************************************/

#include "hal_data.h"
#include "ecat_def.h"
#include "ecatappl.h"
#include "ecatslv.h"
#include "applInterface.h"
#include "r_fw_up_rz_if.h"
#if (CiA402_SAMPLE_APPLICATION == 1)
#include "cia402appl.h"
#else
#include "sampleappl.h"
#endif
#include "renesashw.h"
#include "sio_char.h"
#include <stdio.h>

void R_BSP_WarmStart(bsp_warm_start_event_t event) BSP_PLACE_IN_SECTION(".warm_start");

#if defined(BOARD_RZT2L_RSK)
extern fsp_err_t R_ETHER_PHY_StartAutoNegotiate (ether_phy_ctrl_t * const p_ctrl);
#endif
void handle_error(fsp_err_t err);

/** Use for UART communication */
void user_uart_callback (uart_callback_args_t * p_args);
uint8_t  g_out_of_band_received[TRANSFER_LENGTH];
volatile uint32_t g_transfer_complete = 0;
volatile uint32_t g_receive_complete  = 0;
uint32_t g_out_of_band_index = 0;

/*******************************************************************************************************************//**
 * @brief  EtherCAT Slave Stack example application
 *
 * The EtherCAT Slave Stack Code is provided by SSC tool.
 *
 **********************************************************************************************************************/
void hal_entry (void)
{
	fsp_err_t err;

	/* Open the transfer instance with initial configuration. */
	err = R_SCI_UART_Open(&g_uart0_ctrl, &g_uart0_cfg);
	handle_error(err);
        if(err==0) printf("%s","uart open ok \r\n");
    /* Open the QSPI instance */
    err = R_XSPI_QSPI_Open(&g_qspi0_ctrl, &g_qspi0_cfg);
	handle_error(err);
        if(err==0)  printf("%s","xspi open ok \r\n");
#if defined(BOARD_RZT2M_RSK) && (BSP_CFG_CORE_CR52 == 1)
    /* Open the shared memory driver. */
    err = R_SHARED_MEMORY_Open(&g_shared_memory0_ctrl, &g_shared_memory0_cfg);
    handle_error(err);
#endif

#if defined(BOARD_RZT2L_RSK)
	ethercat_ssc_port_extend_cfg_t * p_ethercat_ssc_port_ext_cfg;
	ether_phy_instance_t * p_ether_phy0;
	ether_phy_instance_t * p_ether_phy1;

	p_ethercat_ssc_port_ext_cfg = (ethercat_ssc_port_extend_cfg_t *)gp_ethercat_ssc_port->p_cfg->p_extend;
	p_ether_phy0 = (ether_phy_instance_t *)p_ethercat_ssc_port_ext_cfg->p_ether_phy_instance[0];
	p_ether_phy1 = (ether_phy_instance_t *)p_ethercat_ssc_port_ext_cfg->p_ether_phy_instance[1];
#endif

	/* Initialize EtherCAT SSC Port */
	err = RM_ETHERCAT_SSC_PORT_Open(gp_ethercat_ssc_port->p_ctrl, gp_ethercat_ssc_port->p_cfg);
	handle_error(err);
        if(err==0)  printf("%s","EC open OK \r\n");
        else printf("%s","EC open fail \r\n");
#if defined(BOARD_RZT2L_RSK)
	/* RZ/T2L RSK board needs starting auto negotiation by phy register access */
	R_ETHER_PHY_StartAutoNegotiate(p_ether_phy0->p_ctrl);
	R_ETHER_PHY_StartAutoNegotiate(p_ether_phy1->p_ctrl);
#endif

	/* Enable interrupt */
	__asm volatile ("cpsie i");

	/* Print that the EtherCAT Sample starts */
#if defined(BOARD_RZT2M_RSK)
#if (BANK == 0)
	char start_messege[] = "RZ/T2M EtherCAT sample program starts on BANK0.\r\n";
#elif (BANK == 1)
    char start_messege[] = "RZ/T2M EtherCAT sample program starts on BANK1.\r\n";
#endif
#endif
#if defined(BOARD_RZT2L_RSK)
#if (BANK == 0)
    char start_messege[] = "RZ/T2L EtherCAT sample program starts on BANK0.\r\n";
#elif (BANK == 1)
    char start_messege[] = "RZ/T2L EtherCAT sample program starts on BANK1.\r\n";
#endif
#endif
#if defined(BOARD_RZN2L_RSK)
#if (BANK == 0)
    char start_messege[] = "RZ/N2L EtherCAT sample program starts on BANK0.\r\n";
#elif (BANK == 1)
    char start_messege[] = "RZ/N2L EtherCAT sample program starts on BANK1.\r\n";
#endif
#endif
    /* Send massage to PC by UART communication. */
    printf("%s",start_messege);

	/* Initilize the stack */
	MainInit();
#if (CiA402_SAMPLE_APPLICATION == 1)
	/* Initialize axis structures */
	CiA402_Init();
#endif

	/* Create basic mapping */
	APPL_GenerateMapping(&nPdInputSize,&nPdOutputSize);
	/* Set stack run flag */
	bRunApplication = TRUE;

	/* Execute the stack */
	while(bRunApplication == TRUE)
	{
		MainLoop();
	}
#if (CiA402_SAMPLE_APPLICATION == 1)
	/* Remove all allocated axes resources */
	CiA402_DeallocateAxis();
#endif
	/* Close SSC Port */
	RM_ETHERCAT_SSC_PORT_Close(gp_ethercat_ssc_port->p_ctrl);
}

void handle_error(fsp_err_t err)
{
	FSP_PARAMETER_NOT_USED(err);
}

/*******************************************************************************************************************//**
 * This function is called at various points during the startup process.  This implementation uses the event that is
 * called right before main() to set up the pins.
 *
 * @param[in]  event    Where at in the start up process the code is currently at
 **********************************************************************************************************************/
void R_BSP_WarmStart(bsp_warm_start_event_t event)
{
    if (BSP_WARM_START_RESET == event)
    {
        /* Pre clock initialization */
    }

    if (BSP_WARM_START_POST_C == event)
    {
        /* C runtime environment and system clocks are setup. */

        if (NULL != g_bsp_pin_cfg.p_extend)
        {
            /* Configure pins. */
            R_IOPORT_Open (&g_ioport_ctrl, &g_bsp_pin_cfg);
        }
    }
}

void user_uart_callback (uart_callback_args_t * p_args)
{
    /* Handle the UART event */
    switch (p_args->event)
    {
        /* Received a character */
        case UART_EVENT_RX_CHAR:
        {
            /* Only put the next character in the receive buffer if there is space for it */
            if (sizeof(g_out_of_band_received) > g_out_of_band_index)
            {
                /* Write either the next one or two bytes depending on the receive data size */
                if ((UART_DATA_BITS_7 == g_uart0_cfg.data_bits) || (UART_DATA_BITS_8 == g_uart0_cfg.data_bits))
                {
                    g_out_of_band_received[g_out_of_band_index++] = (uint8_t) p_args->data;
                }
                else
                {
                    uint16_t * p_dest = (uint16_t *) &g_out_of_band_received[g_out_of_band_index];
                    *p_dest              = (uint16_t) p_args->data;
                    g_out_of_band_index += 2;
                }
            }
            break;
        }
        /* Receive complete */
        case UART_EVENT_RX_COMPLETE:
        {
            g_receive_complete = 1;
            break;
        }
        /* Transmit complete */
        case UART_EVENT_TX_COMPLETE:
        {
            g_transfer_complete = 1;
            break;
        }
        default:
        {
        }
    }
}
