/* generated configuration header file - do not edit */
#ifndef R_XSPI_QSPI_CFG_H_
#define R_XSPI_QSPI_CFG_H_
#define XSPI_QSPI_CFG_PARAM_CHECKING_ENABLE      (BSP_CFG_PARAM_CHECKING_ENABLE)
#define XSPI_QSPI_CFG_UNIT_0_PREFETCH_FUNCTION   (0)
#define XSPI_QSPI_CFG_UNIT_1_PREFETCH_FUNCTION   (0)
#endif /* R_XSPI_QSPI_CFG_H_ */
